function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6es9gcgq2Mc":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

